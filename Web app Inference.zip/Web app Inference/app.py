# -*- coding: utf-8 -*-
"""
Created on Sat Mar  5 20:29:34 2022

@author: Roji Augustine
Reference : https://github.com/ayushkumarshah
"""

import os
import logging
import streamlit as st
import numpy as np
import librosa, librosa.display
import matplotlib.pyplot as plt
from PIL import Image
import tensorflow as tf
import base64


import pyaudio, wave, pylab
from scipy.io.wavfile import write
st.set_option('deprecation.showPyplotGlobalUse', False)

DURATION = 1
WAVE_OUTPUT_FILE = os.path.join('./', "recorded.wav")
SPECTROGRAM_FILE = os.path.join('./', "spectrogram.png")
MODEL_FILE = os.path.join('./', "keras_digit")
INPUT_DEVICE = 0
MAX_INPUT_CHANNELS = 1  # Max input channels
DEFAULT_SAMPLE_RATE = 44100   # Default sample rate of microphone or recording device
CHUNK_SIZE = 1024


class Sound(object):
    def __init__(self):
        # Set default configurations for recording device
        # sd.default.samplerate = DEFAULT_SAMPLE_RATE
        # sd.default.channels = DEFAULT_CHANNELS
        self.format = pyaudio.paInt16
        self.channels = MAX_INPUT_CHANNELS
        self.sample_rate = DEFAULT_SAMPLE_RATE
        self.chunk = CHUNK_SIZE
        self.duration = DURATION
        self.path = WAVE_OUTPUT_FILE
        self.device = INPUT_DEVICE
        self.frames = []
        self.audio = pyaudio.PyAudio()
        self.device_info()
        print()
        logging.info("Audio device configurations currently used")
        logging.info(f"Default input device index = {self.device}")
        logging.info(f"Max input channels = {self.channels}")
        logging.info(f"Default samplerate = {self.sample_rate}")

    def device_info(self):
        num_devices = self.audio.get_device_count()
        keys = ['name', 'index', 'maxInputChannels', 'defaultSampleRate']
        logging.info(f"List of System's Audio Devices configurations:")
        logging.info(f"Number of audio devices: {num_devices}")
        for i in range(num_devices):
            info_dict = self.audio.get_device_info_by_index(i)
            logging.info([(key, value) for key, value in info_dict.items() if key in keys])

    def record(self):
        # start Recording
        self.audio = pyaudio.PyAudio()
        stream = self.audio.open(
                        format=self.format,
                        channels=self.channels,
                        rate=self.sample_rate,
                        input=True,
                        frames_per_buffer=self.chunk,
                        input_device_index=self.device)
        logging.info(f"Recording started for {self.duration} seconds")
        self.frames = []
        for i in range(0, int(self.sample_rate / self.chunk * self.duration)):
            data = stream.read(self.chunk)
            self.frames.append(data)
        logging.info ("Recording Completed")
        # stop Recording
        stream.stop_stream()
        stream.close()
        self.audio.terminate()
        self.save()

    def save(self):
        waveFile = wave.open(self.path, 'wb')
        waveFile.setnchannels(self.channels)
        waveFile.setsampwidth(self.audio.get_sample_size(self.format))
        waveFile.setframerate(self.sample_rate)
        waveFile.writeframes(b''.join(self.frames))
        waveFile.close()
        logging.info(f"Recording saved to {self.path}")


sound = Sound()

def init_model():
    model = tf.keras.models.load_model(MODEL_FILE)
    print(model)
    return model

def get_spectrogram(type='mel'):
    logging.info("Extracting spectrogram")
    y, sr = librosa.load(WAVE_OUTPUT_FILE, duration=DURATION)
    ps = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=128)
    logging.info("Spectrogram Extracted")
    format = '%+2.0f'
    if type == 'DB':
        ps = librosa.power_to_db(ps, ref=np.max)
        format = ''.join[format, 'DB']
        logging.info("Converted to DB scale")
    return ps, format

def display(spectrogram, format):
    plt.figure(figsize=(10, 4))
    librosa.display.specshow(spectrogram, y_axis='mel', x_axis='time')
    plt.title('Mel-frequency spectrogram')
    plt.colorbar(format=format)
    plt.tight_layout()
    st.pyplot(clear_figure=False)

def features_extractor(audio, sample_rate):
    mfccs_features = librosa.feature.mfcc(y=audio, sr=sample_rate, n_mfcc=40)
    mfccs_scaled_features = np.mean(mfccs_features.T,axis=0)    
    return mfccs_scaled_features    

def main():
    
    title = "0 - 9 Digit Recognition"

    st.title(title)
    model = init_model()
    image = Image.open('digits.jpg')
    #st.image(image, use_column_width=True)
    st.image(image) 
    if st.button('Record'):
        with st.spinner(f'Recording for {DURATION} seconds ....'):
            sound.record()
        st.success("Recording completed")

    if st.button('Play'):
        try:
            audio_file = open(WAVE_OUTPUT_FILE, 'rb')
            audio_bytes = audio_file.read()
            st.audio(audio_bytes, format='audio/wav')
        except:
            st.write("Please record sound first")

    if st.button('Classify'):
         try:
             audio, sample_rate = librosa.load(WAVE_OUTPUT_FILE, res_type='kaiser_fast')
             print(audio.shape, sample_rate)
             X = features_extractor(audio, sample_rate)          
             pstr = f'Predicted class : {np.argmax(model.predict(X.reshape(1,1,-1)))}'
             st.write(pstr)
         except Exception as err:    
             st.write("Please record sound first") 
    st.write("\n")

    # Add a placeholder
    if st.button('Display Spectrogram'):
        if os.path.exists(WAVE_OUTPUT_FILE):
            spectrogram, format = get_spectrogram(type='mel')
            display(spectrogram, format)
        else:
            st.write("Please record sound first")

if __name__ == '__main__':
    main()